<?php
include "layouts/head.php";
include  "layouts/nav.php";
$array = [3,4,56,6,4];
echo count($array);

?>


<?php
include "layouts/footer.php";

?>