

<section class="hero-wrap hero-wrap-2" style="background-image: url('<?=$banner_location?>');" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text align-items-end">
          <div class="col-md-9 ftco-animate pb-5">
          	<p class="breadcrumbs mb-2"><span class="mr-2"><a href="index.php">Home <i class="ion-ios-arrow-forward"></i></a></span> <span class="mr-2"></i></a></span> <span><?=$banner_heading?> <i class="ion-ios-arrow-forward"></i></span></p>
            <h1 class="mb-0 bread"><?=$banner_heading?></h1>
          </div>
        </div>
      </div>
    </section>
